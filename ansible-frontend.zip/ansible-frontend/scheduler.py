from apscheduler.schedulers.background import BackgroundScheduler
from app import run_playbook

scheduler = BackgroundScheduler()
scheduler.start()

def schedule_job(playbook, extra_vars, db):
    scheduler.add_job(run_playbook, 'date', args=[playbook, extra_vars, db])
