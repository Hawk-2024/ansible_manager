from flask import Flask, render_template, request, redirect, url_for
from models import db, Job
import ansible_runner
import os
from scheduler import schedule_job

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db.init_app(app)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def run_playbook(playbook, extra_vars, db_session=None):
    run_dir = os.path.join(BASE_DIR, 'runner_data')
    os.makedirs(run_dir, exist_ok=True)

    vars_file = os.path.join(run_dir, 'env', 'extravars')
    os.makedirs(os.path.dirname(vars_file), exist_ok=True)
    with open(vars_file, 'w') as f:
        f.write(extra_vars)

    r = ansible_runner.run(
        private_data_dir=run_dir,
        playbook=os.path.join('playbooks', playbook),
        inventory=os.path.join(BASE_DIR, 'inventories', 'hosts')
    )

    output = r.stdout.read()
    status = r.status

    job = Job(playbook=playbook, extra_vars=extra_vars, output=output, status=status)
    if db_session:
        db_session.session.add(job)
        db_session.session.commit()
    else:
        with app.app_context():
            db.session.add(job)
            db.session.commit()

    return output

@app.route('/', methods=['GET', 'POST'])
def index():
    output = None
    if request.method == 'POST':
        playbook = request.form['playbook']
        extra_vars = request.form.get('extra_vars', '')
        schedule = request.form.get('schedule', '')

        if schedule:
            schedule_job(playbook, extra_vars, db)
        else:
            output = run_playbook(playbook, extra_vars)

    playbooks = os.listdir(os.path.join(BASE_DIR, 'playbooks'))
    return render_template('index.html', playbooks=playbooks, output=output)

@app.route('/history')
def history():
    jobs = Job.query.order_by(Job.created_at.desc()).all()
    return render_template('history.html', jobs=jobs)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
